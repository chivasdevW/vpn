# ezyvpn (Android) 2.0

WireGuard tabanli VPN istemcisi. Kotlin + Jetpack Compose.

Ozellikler: Ana sayfa (baglan/kapat, sure, indirme/yukleme), Sunucular (bayrak, ping, ekle/sil),
Ayarlar (otomatik baglan, dil TR/EN, kill switch kisayolu, VPN disinda kalacak uygulamalar),
Hakkinda, QR / dosya ile config iceri aktarma, uygulama ikonu.

## Sunucu ekleme
1. Bir VPS kirala (Ubuntu 22.04/24.04), `server-setup/setup-wireguard.sh` dosyasini sunucuya at:
   `sudo bash setup-wireguard.sh "Almanya" "🇩🇪"`
2. Betik iki cikti verir: bir JSON satiri ve bir QR kod.
3. Hizli yol: telefonda Sunucular > Ekle > QR tara.
4. Hazir sunucu yolu: JSON satirini `app/src/main/assets/servers.json` icindeki ilgili yuvanin yerine koy, APK'yi yeniden derle.
   (Dikkat: bu yolda cihaz anahtari APK'nin icine girer, APK'yi baskalarina dagitma.)

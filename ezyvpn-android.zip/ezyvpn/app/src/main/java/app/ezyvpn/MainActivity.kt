package app.ezyvpn

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings as AndroidSettings
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning
import com.wireguard.android.backend.GoBackend
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.light(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.light(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT)
        )
        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = Accent, onPrimary = Color.White,
                    background = Bg, onBackground = TextDark,
                    surface = Card, onSurface = TextDark
                )
            ) {
                Surface(color = Bg, modifier = Modifier.fillMaxSize()) { EzyApp() }
            }
        }
    }
}

// ---------------------------------------------------------------- Kabuk (menu + ust cubuk)

@Composable
fun EzyApp(vm: VpnViewModel = viewModel()) {
    val context = LocalContext.current
    val status by vm.status.collectAsStateWithLifecycle()
    val servers by vm.servers.collectAsStateWithLifecycle()
    val selected by vm.selected.collectAsStateWithLifecycle()
    val pings by vm.pings.collectAsStateWithLifecycle()
    val seconds by vm.seconds.collectAsStateWithLifecycle()
    val traffic by vm.traffic.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val lang = settings.lang

    var screen by rememberSaveable { mutableIntStateOf(0) }
    var showAdd by remember { mutableStateOf(false) }
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    val permission = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { if (it.resultCode == Activity.RESULT_OK) vm.connect() }

    fun toggle() {
        when (status) {
            VpnStatus.Connected -> vm.disconnect()
            VpnStatus.Connecting -> Unit
            else -> {
                val intent = GoBackend.VpnService.prepare(context)
                if (intent != null) permission.launch(intent) else vm.connect()
            }
        }
    }

    LaunchedEffect(Unit) {
        vm.refreshPings()
        if (settings.autoConnect && status == VpnStatus.Disconnected && selected != null) toggle()
    }

    BackHandler(enabled = drawerState.isOpen || screen != 0) {
        if (drawerState.isOpen) scope.launch { drawerState.close() } else screen = 0
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(drawerContainerColor = Card) {
                Row(Modifier.padding(start = 28.dp, top = 40.dp, bottom = 24.dp), verticalAlignment = Alignment.CenterVertically) { Logo(30.dp) }
                val items = listOf(
                    Triple(tx(lang, "Ana sayfa", "Home"), Icons.Filled.Home, 0),
                    Triple(tx(lang, "Sunucular", "Servers"), Icons.AutoMirrored.Filled.List, 1),
                    Triple(tx(lang, "Ayarlar", "Settings"), Icons.Filled.Settings, 2),
                    Triple(tx(lang, "Hakkında", "About"), Icons.Filled.Info, 3)
                )
                items.forEach { (label, icon, i) ->
                    NavigationDrawerItem(
                        label = { Text(label) },
                        icon = { Icon(icon, contentDescription = null) },
                        selected = screen == i,
                        onClick = { screen = i; scope.launch { drawerState.close() } },
                        modifier = Modifier.padding(horizontal = 12.dp),
                        colors = NavigationDrawerItemDefaults.colors(
                            selectedContainerColor = AccentSoft, selectedIconColor = Accent, selectedTextColor = Accent,
                            unselectedContainerColor = Color.Transparent, unselectedIconColor = Muted, unselectedTextColor = TextDark
                        )
                    )
                }
            }
        }
    ) {
        Column(Modifier.fillMaxSize().background(Bg).statusBarsPadding().navigationBarsPadding()) {
            TopBar(onMenu = { scope.launch { drawerState.open() } })
            Box(Modifier.weight(1f).fillMaxWidth()) {
                when (screen) {
                    0 -> HomeScreen(lang, status, selected, selected?.let { pings[it.id] }, seconds, traffic, ::toggle) { screen = 1 }
                    1 -> ServersScreen(
                        lang, servers, selected?.id, pings, status == VpnStatus.Connected,
                        onSelect = { vm.select(it); screen = 0 }, onDelete = vm::removeServer,
                        onAdd = { showAdd = true }, onRefresh = vm::refreshPings
                    )
                    2 -> SettingsScreen(lang, settings, vm::setAutoConnect, vm::setLang, vm::setExcluded)
                    else -> AboutScreen(lang)
                }
            }
        }
    }

    if (showAdd) AddServerDialog(
        lang = lang,
        onDismiss = { showAdd = false },
        onSave = { name, cfg -> vm.addServer(name, cfg); showAdd = false }
    )
}

@Composable
private fun Logo(height: Dp = 26.dp) {
    Image(painterResource(R.drawable.ezy_logo), contentDescription = "ezy", modifier = Modifier.height(height))
    Text("vpn", color = Muted, fontSize = (height.value * 0.8f).sp, modifier = Modifier.padding(start = 4.dp))
}

@Composable
private fun TopBar(onMenu: () -> Unit) {
    Box(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 10.dp)) {
        IconButton(onClick = onMenu, modifier = Modifier.align(Alignment.CenterStart)) {
            Icon(Icons.Filled.Menu, contentDescription = "Menu", tint = Accent)
        }
        Row(Modifier.align(Alignment.Center), verticalAlignment = Alignment.CenterVertically) { Logo(26.dp) }
    }
}

// ---------------------------------------------------------------- Ana sayfa

@Composable
fun HomeScreen(
    lang: String, status: VpnStatus, server: Server?, ping: Int?,
    seconds: Long, traffic: Pair<Long, Long>, onToggle: () -> Unit, onPickServer: () -> Unit
) {
    val connected = status == VpnStatus.Connected
    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {

        // noktali panel: guc dugmesi + durum
        Column(
            Modifier.fillMaxWidth().weight(1f).background(Panel).drawBehind {
                val step = 16.dp.toPx()
                var y = step / 2
                while (y < size.height) {
                    var x = step / 2
                    while (x < size.width) {
                        drawCircle(Line, radius = 1.3.dp.toPx(), center = Offset(x, y))
                        x += step
                    }
                    y += step
                }
            },
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            PowerButton(status, enabled = server != null, onClick = onToggle)
            Spacer(Modifier.height(24.dp))
            Box(
                Modifier.shadow(2.dp, RoundedCornerShape(50)).background(Card, RoundedCornerShape(50))
                    .padding(horizontal = 30.dp, vertical = 10.dp)
            ) {
                Text(
                    when (status) {
                        VpnStatus.Connected -> tx(lang, "Bağlandı", "Connected")
                        VpnStatus.Connecting -> tx(lang, "Bağlanıyor…", "Connecting…")
                        is VpnStatus.Failed -> tx(lang, "Bağlanamadı", "Failed")
                        VpnStatus.Disconnected ->
                            if (server == null) tx(lang, "Sunucu ekle", "Add a server")
                            else tx(lang, "Bağlı değil", "Not connected")
                    },
                    color = when (status) {
                        VpnStatus.Connected, VpnStatus.Connecting -> Accent
                        is VpnStatus.Failed -> Danger
                        else -> Muted
                    },
                    fontSize = 18.sp, fontWeight = FontWeight.SemiBold
                )
            }
        }

        Spacer(Modifier.height(20.dp))
        Text(fmtTime(seconds), fontSize = 30.sp, fontWeight = FontWeight.SemiBold, color = if (connected) TextDark else Muted)

        (status as? VpnStatus.Failed)?.let {
            Text(it.message, color = Danger, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 24.dp, vertical = 4.dp))
        }
        if (connected) {
            Spacer(Modifier.height(4.dp))
            Text("↓ ${fmtBytes(traffic.first)}    ↑ ${fmtBytes(traffic.second)}", color = Muted, fontSize = 13.sp)
        }

        Spacer(Modifier.height(18.dp))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
            Text("WireGuard", color = Muted, fontSize = 16.sp)
            Box(Modifier.padding(horizontal = 12.dp).width(1.dp).height(18.dp).background(Line))
            Text(server?.port ?: "—", color = Muted, fontSize = 16.sp)
            Spacer(Modifier.width(28.dp))
            Icon(Icons.Filled.Lock, null, tint = if (connected) TextDark else Muted, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(6.dp))
            Text(server?.host ?: "—", color = TextDark, fontSize = 16.sp, fontWeight = FontWeight.Medium)
        }

        Spacer(Modifier.height(20.dp))
        LocationCard(lang, server, ping, onPickServer)
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
private fun LocationCard(lang: String, server: Server?, ping: Int?, onClick: () -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    Row(
        Modifier.padding(horizontal = 24.dp).fillMaxWidth()
            .shadow(2.dp, shape).background(Card, shape).clip(shape)
            .clickable(onClick = onClick).padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(width = 56.dp, height = 40.dp).clip(RoundedCornerShape(6.dp)).background(Bg), contentAlignment = Alignment.Center) {
            Text(server?.flag ?: "🌐", fontSize = 26.sp)
        }
        Spacer(Modifier.width(16.dp))
        Column(Modifier.weight(1f)) {
            Text(server?.name ?: tx(lang, "Sunucu seç", "Choose a server"), fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = TextDark)
            Text(
                server?.let { if (ping != null) "$ping ms" else tx(lang, "Seçili sunucu", "Selected server") } ?: tx(lang, "Henüz sunucu yok", "No server yet"),
                color = Muted, fontSize = 15.sp
            )
        }
        if (server != null) { SignalBars(ping); Spacer(Modifier.width(16.dp)) }
        Text("›", fontSize = 28.sp, color = Muted)
    }
}

@Composable
private fun SignalBars(ping: Int?) {
    val level = when {
        ping == null -> 0
        ping < 60 -> 4
        ping < 120 -> 3
        ping < 200 -> 2
        else -> 1
    }
    Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(2.dp)) {
        (1..4).forEach { i ->
            Box(
                Modifier.width(4.dp).height((6 + i * 4).dp).clip(RoundedCornerShape(1.dp))
                    .background(if (i <= level) TextDark else Line)
            )
        }
    }
}

@Composable
private fun PowerButton(status: VpnStatus, enabled: Boolean, onClick: () -> Unit) {
    val palette = when (status) {
        VpnStatus.Connected -> listOf(Color(0xFFFFB27A), Color(0xFFF26A1B), Color(0xFFFF8A3D), Color(0xFFE85D0C))
        VpnStatus.Connecting -> listOf(Color(0xFFFFD2B0), Color(0xFFFFA566), Color(0xFFFFA566), Color(0xFFFF8A3D))
        is VpnStatus.Failed -> listOf(Color(0xFFF2A3A3), Color(0xFFD64545), Color(0xFFE06666), Color(0xFFC53030))
        VpnStatus.Disconnected -> listOf(Color(0xFFD5DBE1), Color(0xFFB8C1CA), Color(0xFFA3ADB8), Color(0xFF7B8794))
    }
    val r1 by animateColorAsState(palette[0], label = "r1")
    val r2 by animateColorAsState(palette[1], label = "r2")
    val c1 by animateColorAsState(palette[2], label = "c1")
    val c2 by animateColorAsState(palette[3], label = "c2")

    Box(
        Modifier.size(236.dp).clip(CircleShape).background(Brush.linearGradient(listOf(r1, r2)))
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Box(Modifier.size(216.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.92f)), contentAlignment = Alignment.Center) {
            Box(Modifier.size(190.dp).clip(CircleShape).background(Brush.linearGradient(listOf(c1, c2))), contentAlignment = Alignment.Center) {
                Canvas(Modifier.size(72.dp)) {
                    val sw = 5.dp.toPx()
                    val r = size.width * 0.38f
                    val c = Offset(size.width / 2, size.height * 0.56f)
                    drawArc(
                        color = Color.White, startAngle = -60f, sweepAngle = 300f, useCenter = false,
                        topLeft = Offset(c.x - r, c.y - r), size = Size(2 * r, 2 * r),
                        style = Stroke(width = sw, cap = StrokeCap.Round)
                    )
                    drawLine(Color.White, Offset(c.x, size.height * 0.06f), Offset(c.x, c.y), strokeWidth = sw, cap = StrokeCap.Round)
                }
            }
        }
    }
}

// ---------------------------------------------------------------- Sunucular

@Composable
fun ServersScreen(
    lang: String, servers: List<Server>, selectedId: String?, pings: Map<String, Int?>,
    locked: Boolean, onSelect: (Server) -> Unit, onDelete: (Server) -> Unit,
    onAdd: () -> Unit, onRefresh: () -> Unit
) {
    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 24.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(tx(lang, "Sunucular", "Servers"), fontSize = 22.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                TextButton(onClick = onRefresh) { Text(tx(lang, "Ping ölç", "Test ping")) }
                TextButton(onClick = onAdd) { Text(tx(lang, "Ekle", "Add")) }
            }
        }
        if (locked) item {
            Text(tx(lang, "Sunucuyu değiştirmek için önce bağlantıyı kapat.", "Disconnect to change server."), color = Muted, fontSize = 13.sp)
        }
        items(servers, key = { it.id }) { s ->
            val active = s.id == selectedId
            val ping = pings[s.id]
            val shape = RoundedCornerShape(14.dp)
            Row(
                Modifier.fillMaxWidth().shadow(2.dp, shape)
                    .background(if (active) AccentSoft else Card, shape).clip(shape)
                    .clickable(enabled = s.configured && !locked) { onSelect(s) }
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(s.flag, fontSize = 26.sp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(s.name, fontWeight = FontWeight.Medium, color = if (s.configured) TextDark else Muted)
                    Text(
                        when {
                            !s.configured -> tx(lang, "Yapılandırılmadı", "Not configured")
                            active -> tx(lang, "Seçili", "Selected")
                            s.builtin -> tx(lang, "Hazır sunucu", "Built-in")
                            else -> tx(lang, "Eklediğin sunucu", "Your server")
                        },
                        color = if (active) Accent else Muted, fontSize = 12.sp
                    )
                }
                if (s.configured) { SignalBars(ping); Spacer(Modifier.width(8.dp)); Text(if (ping != null) "$ping ms" else "—", color = Muted) }
                if (!s.builtin) TextButton(onClick = { onDelete(s) }, enabled = !locked) { Text(tx(lang, "Sil", "Delete"), color = Danger) }
            }
        }
        item { Spacer(Modifier.height(16.dp)) }
    }
}

@Composable
private fun AddServerDialog(lang: String, onDismiss: () -> Unit, onSave: (String, String) -> Unit) {
    val context = LocalContext.current
    var name by remember { mutableStateOf("") }
    var config by remember { mutableStateOf("") }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            runCatching {
                context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { config = it.readText() }
            }
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tx(lang, "Sunucu ekle", "Add server")) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text(tx(lang, "Sunucu adı", "Server name")) }, singleLine = true)
                Row {
                    TextButton(onClick = {
                        GmsBarcodeScanning.getClient(context).startScan()
                            .addOnSuccessListener { b -> b.rawValue?.let { config = it } }
                    }) { Text(tx(lang, "QR tara", "Scan QR")) }
                    TextButton(onClick = { picker.launch(arrayOf("*/*")) }) { Text(tx(lang, "Dosyadan al", "Import file")) }
                }
                OutlinedTextField(
                    config, { config = it }, label = { Text("WireGuard config") },
                    placeholder = { Text("[Interface] … [Peer] …") }, minLines = 5, maxLines = 8
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { onSave(name, config) }, enabled = name.isNotBlank() && config.contains("[Peer]")) {
                Text(tx(lang, "Kaydet", "Save"))
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tx(lang, "Vazgeç", "Cancel")) } }
    )
}

// ---------------------------------------------------------------- Ayarlar

@Composable
fun SettingsScreen(
    lang: String, settings: AppSettings,
    onAuto: (Boolean) -> Unit, onLang: (String) -> Unit, onExcluded: (Set<String>) -> Unit
) {
    val context = LocalContext.current
    var showApps by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp), verticalArrangement = Arrangement.spacedBy(22.dp)) {
        Text(tx(lang, "Ayarlar", "Settings"), fontSize = 22.sp, fontWeight = FontWeight.SemiBold)

        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(tx(lang, "Açılışta otomatik bağlan", "Connect on app start"))
                Text(tx(lang, "Uygulamayı açınca seçili sunucuya bağlanır.", "Connects to the selected server when the app opens."), color = Muted, fontSize = 12.sp)
            }
            Switch(settings.autoConnect, onAuto)
        }

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(tx(lang, "Dil", "Language"))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip("Türkçe", settings.lang == "tr") { onLang("tr") }
                Chip("English", settings.lang == "en") { onLang("en") }
            }
        }

        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(tx(lang, "Kill switch (bağlantı kopunca interneti kes)", "Kill switch (block traffic if VPN drops)"))
            Text(
                tx(lang, "Android bunu uygulamaların yerine sistem ayarlarında yönetir. Açılan ekranda ezyvpn için “Her zaman açık VPN” ve “VPN olmadan bağlantıları engelle” seçeneklerini aç.",
                    "Android manages this in system settings. On the next screen enable “Always-on VPN” and “Block connections without VPN” for ezyvpn."),
                color = Muted, fontSize = 12.sp
            )
            TextButton(onClick = { context.startActivity(Intent(AndroidSettings.ACTION_VPN_SETTINGS)) }) {
                Text(tx(lang, "VPN ayarlarını aç", "Open VPN settings"))
            }
        }

        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(tx(lang, "VPN dışında kalacak uygulamalar", "Apps that bypass the VPN"))
            Text(
                tx(lang, "Seçtiklerin VPN'e girmez, doğrudan internete çıkar. Şu an: ${settings.excluded.size} uygulama. Değişiklik bir sonraki bağlanışta geçerli olur.",
                    "Selected apps skip the VPN. Currently: ${settings.excluded.size}. Applies on next connect."),
                color = Muted, fontSize = 12.sp
            )
            TextButton(onClick = { showApps = true }) { Text(tx(lang, "Uygulama seç", "Choose apps")) }
        }
    }

    if (showApps) AppPickerDialog(lang, settings.excluded, onDismiss = { showApps = false }) { onExcluded(it); showApps = false }
}

@Composable
private fun Chip(text: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.clip(RoundedCornerShape(50)).background(if (selected) Accent else Panel)
            .clickable(onClick = onClick).padding(horizontal = 18.dp, vertical = 8.dp)
    ) { Text(text, color = if (selected) Color.White else TextDark) }
}

private fun loadApps(context: Context): List<Pair<String, String>> {
    val pm = context.packageManager
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(intent, 0)
        .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
        .filter { it.first != context.packageName }
        .distinctBy { it.first }
        .sortedBy { it.second.lowercase() }
}

@Composable
private fun AppPickerDialog(lang: String, selected: Set<String>, onDismiss: () -> Unit, onDone: (Set<String>) -> Unit) {
    val context = LocalContext.current
    val apps by produceState<List<Pair<String, String>>>(emptyList()) {
        value = withContext(Dispatchers.IO) { loadApps(context) }
    }
    var chosen by remember { mutableStateOf(selected) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tx(lang, "VPN dışında kalacak uygulamalar", "Apps that bypass the VPN")) },
        text = {
            LazyColumn(Modifier.heightIn(max = 380.dp)) {
                items(apps, key = { it.first }) { (pkg, label) ->
                    Row(
                        Modifier.fillMaxWidth()
                            .clickable { chosen = if (pkg in chosen) chosen - pkg else chosen + pkg }
                            .padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(checked = pkg in chosen, onCheckedChange = null)
                        Spacer(Modifier.width(12.dp))
                        Text(label)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { onDone(chosen) }) { Text(tx(lang, "Kaydet", "Save")) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tx(lang, "Vazgeç", "Cancel")) } }
    )
}

// ---------------------------------------------------------------- Hakkinda

@Composable
fun AboutScreen(lang: String) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { Logo(40.dp) }
        Text(tx(lang, "Sürüm 2.1", "Version 2.1"), color = Muted)
        Text(
            tx(lang, "ezyvpn, WireGuard protokolüyle çalışan bir VPN istemcisidir. Trafiğin, bağlandığın sunucu üzerinden geçer.",
                "ezyvpn is a VPN client built on the WireGuard protocol. Your traffic goes through the server you connect to.")
        )
        Text(
            tx(lang, "Sunucuyu işleten kişi trafiğini görebilir. Bu yüzden yalnızca güvendiğin sunuculara bağlan; kendi sunucunu kurmak en güvenli yoldur.",
                "Whoever runs the server can see your traffic. Only connect to servers you trust; running your own is the safest option."),
            color = Muted
        )
        Text(
            tx(lang, "Sunucu eklemek için: menü > Sunucular > Ekle > QR tara, dosyadan al ya da config yapıştır.",
                "To add a server: menu > Servers > Add > scan QR, import a file or paste a config."),
            color = Muted
        )
    }
}

package app.ezyvpn

import androidx.compose.ui.graphics.Color

val Bg = Color(0xFFF4F6F8)
val Card = Color(0xFFFFFFFF)
val Panel = Color(0xFFE9EFF3)
val TextDark = Color(0xFF1F2933)
val Muted = Color(0xFF7B8794)
val Line = Color(0xFFD5DBE1)
val Accent = Color(0xFFF26A1B)      // ezy turuncusu
val AccentSoft = Color(0xFFFFE6D6)
val Danger = Color(0xFFD64545)

fun tx(lang: String, tr: String, en: String) = if (lang == "en") en else tr

fun fmtBytes(b: Long): String = when {
    b < 1024 -> "$b B"
    b < 1024L * 1024 -> "%.1f KB".format(b / 1024.0)
    b < 1024L * 1024 * 1024 -> "%.1f MB".format(b / 1024.0 / 1024.0)
    else -> "%.2f GB".format(b / 1024.0 / 1024.0 / 1024.0)
}

fun fmtTime(s: Long): String = "%02d:%02d:%02d".format(s / 3600, (s % 3600) / 60, s % 60)

package app.ezyvpn

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Server(
    val id: String,
    val name: String,
    val flag: String,
    val config: String,
    val builtin: Boolean
) {
    val configured: Boolean get() = config.isNotBlank() && !config.contains("BURAYA")

    val host: String?
        get() = Regex("""Endpoint\s*=\s*\[?([^\]\s]+?)\]?:\d+""", RegexOption.IGNORE_CASE)
            .find(config)?.groupValues?.get(1)

    val port: String?
        get() = Regex("""Endpoint\s*=\s*.+:(\d+)""", RegexOption.IGNORE_CASE)
            .find(config)?.groupValues?.get(1)
}

data class AppSettings(
    val autoConnect: Boolean = false,
    val lang: String = "tr",
    val excluded: Set<String> = emptySet()
)

class SettingsStore(context: Context) {
    private val prefs = context.getSharedPreferences("ezyvpn_settings", Context.MODE_PRIVATE)

    fun load() = AppSettings(
        autoConnect = prefs.getBoolean("auto", false),
        lang = prefs.getString("lang", "tr") ?: "tr",
        excluded = prefs.getStringSet("excluded", emptySet())?.toSet() ?: emptySet()
    )

    fun save(s: AppSettings) {
        prefs.edit()
            .putBoolean("auto", s.autoConnect)
            .putString("lang", s.lang)
            .putStringSet("excluded", s.excluded)
            .apply()
    }
}

/** Kullanicinin ekledigi sunuculari ve secili sunucuyu saklar. */
class ServerStore(context: Context) {
    private val prefs = context.getSharedPreferences("ezyvpn", Context.MODE_PRIVATE)

    fun load(): List<Server> {
        val arr = JSONArray(prefs.getString("user_servers", "[]") ?: "[]")
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Server(o.getString("id"), o.getString("name"), o.optString("flag", "🌐"), o.getString("config"), false)
        }
    }

    fun save(servers: List<Server>) {
        val arr = JSONArray()
        servers.filter { !it.builtin }.forEach {
            arr.put(JSONObject().put("id", it.id).put("name", it.name).put("flag", it.flag).put("config", it.config))
        }
        prefs.edit().putString("user_servers", arr.toString()).apply()
    }

    fun selectedId(): String? = prefs.getString("selected", null)
    fun saveSelected(id: String) = prefs.edit().putString("selected", id).apply()
}

/** assets/servers.json icindeki hazir sunucu yuvalari. */
object BuiltinServers {
    fun load(context: Context): List<Server> = try {
        val text = context.assets.open("servers.json").bufferedReader().use { it.readText() }
        val arr = JSONArray(text)
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            val cfg = buildString {
                appendLine("[Interface]")
                appendLine("PrivateKey = ${o.getString("privateKey")}")
                appendLine("Address = ${o.getString("address")}")
                appendLine("DNS = ${o.optString("dns", "1.1.1.1")}")
                appendLine()
                appendLine("[Peer]")
                appendLine("PublicKey = ${o.getString("publicKey")}")
                appendLine("Endpoint = ${o.getString("endpoint")}")
                appendLine("AllowedIPs = 0.0.0.0/0, ::/0")
                appendLine("PersistentKeepalive = 25")
            }
            Server("b:" + o.getString("name"), o.getString("name"), o.optString("flag", "🌐"), cfg, true)
        }
    } catch (e: Exception) {
        emptyList()
    }
}

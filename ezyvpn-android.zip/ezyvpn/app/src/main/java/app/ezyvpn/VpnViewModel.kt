package app.ezyvpn

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.InetAddress

sealed interface VpnStatus {
    data object Disconnected : VpnStatus
    data object Connecting : VpnStatus
    data object Connected : VpnStatus
    data class Failed(val message: String) : VpnStatus
}

class VpnViewModel(app: Application) : AndroidViewModel(app) {

    private val tunnel = TunnelManager(app)
    private val serverStore = ServerStore(app)
    private val settingsStore = SettingsStore(app)

    private val _status = MutableStateFlow<VpnStatus>(VpnStatus.Disconnected)
    val status: StateFlow<VpnStatus> = _status.asStateFlow()

    private val _servers = MutableStateFlow(BuiltinServers.load(app) + serverStore.load())
    val servers: StateFlow<List<Server>> = _servers.asStateFlow()

    private val _selected = MutableStateFlow(initialSelection())
    val selected: StateFlow<Server?> = _selected.asStateFlow()

    private val _pings = MutableStateFlow<Map<String, Int?>>(emptyMap())
    val pings: StateFlow<Map<String, Int?>> = _pings.asStateFlow()

    private val _seconds = MutableStateFlow(0L)
    val seconds: StateFlow<Long> = _seconds.asStateFlow()

    private val _traffic = MutableStateFlow(0L to 0L)
    val traffic: StateFlow<Pair<Long, Long>> = _traffic.asStateFlow()

    private val _settings = MutableStateFlow(settingsStore.load())
    val settings: StateFlow<AppSettings> = _settings.asStateFlow()

    private var ticker: Job? = null

    private fun initialSelection(): Server? {
        val saved = serverStore.selectedId()
        val all = _servers.value
        return all.firstOrNull { it.id == saved && it.configured } ?: all.firstOrNull { it.configured }
    }

    // ---- sunucular ----
    fun select(server: Server) {
        if (!server.configured) return
        _selected.value = server
        serverStore.saveSelected(server.id)
    }

    fun addServer(name: String, config: String) {
        val server = Server("u:" + System.currentTimeMillis(), name.trim(), "🌐", config.trim(), false)
        _servers.value = _servers.value + server
        serverStore.save(_servers.value)
        if (_selected.value == null) select(server)
        refreshPings()
    }

    fun removeServer(server: Server) {
        if (server.builtin) return
        _servers.value = _servers.value - server
        serverStore.save(_servers.value)
        if (_selected.value == server) _selected.value = _servers.value.firstOrNull { it.configured }
    }

    fun refreshPings() {
        viewModelScope.launch {
            val results = _servers.value.filter { it.configured }.map { s ->
                async(Dispatchers.IO) { s.id to measure(s.host) }
            }.awaitAll()
            _pings.value = results.toMap()
        }
    }

    private fun measure(host: String?): Int? {
        if (host == null) return null
        return try {
            val t = System.nanoTime()
            if (InetAddress.getByName(host).isReachable(1500)) ((System.nanoTime() - t) / 1_000_000).toInt() else null
        } catch (e: Exception) {
            null
        }
    }

    // ---- ayarlar ----
    private fun update(s: AppSettings) {
        _settings.value = s
        settingsStore.save(s)
    }

    fun setAutoConnect(v: Boolean) = update(_settings.value.copy(autoConnect = v))
    fun setLang(v: String) = update(_settings.value.copy(lang = v))
    fun setExcluded(v: Set<String>) = update(_settings.value.copy(excluded = v))

    // ---- baglanti ----
    private fun withExclusions(config: String, excluded: Set<String>): String =
        if (excluded.isEmpty()) config
        else config.replaceFirst("[Interface]", "[Interface]\nExcludedApplications = ${excluded.joinToString(", ")}")

    fun connect() {
        val server = _selected.value ?: return
        if (!server.configured) return
        _status.value = VpnStatus.Connecting
        viewModelScope.launch {
            try {
                tunnel.connect(withExclusions(server.config, _settings.value.excluded))
                _status.value = VpnStatus.Connected
                startTicker()
            } catch (e: Exception) {
                _status.value = VpnStatus.Failed(e.message ?: "Connection failed")
            }
        }
    }

    fun disconnect() {
        ticker?.cancel()
        viewModelScope.launch {
            runCatching { tunnel.disconnect() }
            _status.value = VpnStatus.Disconnected
            _seconds.value = 0
            _traffic.value = 0L to 0L
        }
    }

    private fun startTicker() {
        ticker?.cancel()
        val start = System.currentTimeMillis()
        ticker = viewModelScope.launch {
            while (true) {
                _seconds.value = (System.currentTimeMillis() - start) / 1000
                tunnel.stats()?.let { _traffic.value = it }
                delay(1000)
            }
        }
    }
}

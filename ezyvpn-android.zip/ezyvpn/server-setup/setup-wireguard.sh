#!/usr/bin/env bash
# Kullanim:  sudo bash setup-wireguard.sh "Almanya" "🇩🇪"
# Ubuntu/Debian VPS uzerinde WireGuard kurar ve ezyvpn icin hazir sunucu girdisi uretir.
# Ayni betigi tekrar calistirirsan yeni bir cihaz (peer) eklenir.
set -euo pipefail
[ "$EUID" -eq 0 ] || { echo "root olarak calistir: sudo bash $0"; exit 1; }

NAME="${1:-Sunucum}"
FLAG="${2:-🌐}"
PORT=51820

apt-get update -y
apt-get install -y wireguard qrencode curl iptables

IFACE=$(ip -o -4 route show to default | awk '{print $5}' | head -1)
PUBIP=$(curl -4 -s https://ifconfig.me)

mkdir -p /etc/wireguard
cd /etc/wireguard
umask 077

[ -f server.key ] || { wg genkey | tee server.key | wg pubkey > server.pub; }
SERVER_PRIV=$(cat server.key)
SERVER_PUB=$(cat server.pub)

if [ ! -f wg0.conf ]; then
cat > wg0.conf <<EOF
[Interface]
Address = 10.8.0.1/24
ListenPort = $PORT
PrivateKey = $SERVER_PRIV
PostUp = iptables -A FORWARD -i wg0 -j ACCEPT; iptables -A FORWARD -o wg0 -j ACCEPT; iptables -t nat -A POSTROUTING -o $IFACE -j MASQUERADE
PostDown = iptables -D FORWARD -i wg0 -j ACCEPT; iptables -D FORWARD -o wg0 -j ACCEPT; iptables -t nat -D POSTROUTING -o $IFACE -j MASQUERADE
EOF
fi

echo "net.ipv4.ip_forward=1" > /etc/sysctl.d/99-wg.conf
sysctl -p /etc/sysctl.d/99-wg.conf >/dev/null

# yeni cihaz
N=$(grep -c '^\[Peer\]' wg0.conf || true)
IPN=$((N+2))
CPRIV=$(wg genkey)
CPUB=$(echo "$CPRIV" | wg pubkey)

cat >> wg0.conf <<EOF

[Peer]
PublicKey = $CPUB
AllowedIPs = 10.8.0.$IPN/32
EOF

if ip link show wg0 >/dev/null 2>&1; then
  wg set wg0 peer "$CPUB" allowed-ips "10.8.0.$IPN/32"
else
  systemctl enable --now wg-quick@wg0
fi

command -v ufw >/dev/null 2>&1 && ufw status | grep -q active && ufw allow $PORT/udp || true

CLIENT_CONF="[Interface]
PrivateKey = $CPRIV
Address = 10.8.0.$IPN/32
DNS = 1.1.1.1

[Peer]
PublicKey = $SERVER_PUB
Endpoint = $PUBIP:$PORT
AllowedIPs = 0.0.0.0/0, ::/0
PersistentKeepalive = 25"

echo
echo "=============== 1) servers.json icin girdi ==============="
cat <<EOF
{"name":"$NAME","flag":"$FLAG","endpoint":"$PUBIP:$PORT","publicKey":"$SERVER_PUB","privateKey":"$CPRIV","address":"10.8.0.$IPN/32","dns":"1.1.1.1"}
EOF
echo
echo "=============== 2) Uygulamada QR ile eklemek icin ==============="
echo "$CLIENT_CONF" | qrencode -t ansiutf8
echo
echo "NOT: Bu girdi bir cihaza aittir. Baska cihaz icin betigi yeniden calistir."
